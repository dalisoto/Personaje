from machine import Pin, PWM
from time import sleep
import network 
from time import sleep
from umqtt.simple import MQTTClient 
from machine import Pin

foco1 = Pin(12, Pin.OUT)
foco2 = Pin(14, Pin.OUT)
foco3 = Pin(27, Pin.OUT)
foco4 = Pin(16, Pin.OUT)
foco5 = Pin(17, Pin.OUT)
foco6 = Pin(5, Pin.OUT)

# Declaro servo
servo = PWM(Pin(13), freq=50)
servo.duty(180)

buzzer = PWM(Pin(4), freq=1000, duty=0)
def sonido(frecuencia, duracion):
  buzzer.freq(frecuencia)
  buzzer.duty(512)
  sleep(duracion)  

def reproducir_cancion_personalizada():
    # Notas de la canción personalizada
    notas_personalizadas = [
        (659, 0.125), (659, 0.125), (659, 0.250),
        (659, 0.125), (659, 0.125), (659, 0.250),
        (659, 0.125), (783, 0.125), (523, 0.125), (587, 0.125),
        (659, 1),
        
        (698, 0.125), (698, 0.125), (698, 0.125), (698, 0.125),
        (698, 0.125), (659, 0.125), (659, 0.125), (659, 0.62), (659, 0.62),
        (659, 0.125), (587, 0.125), (587, 0.125), (659, 0.125),
        (587, 0.250), (784, 0.125)
    ]

    for nota, duracion in notas_personalizadas:
        sonido(nota, duracion)

#buzzer
    
        


MQTT_BROKER = "broker.hivemq.com"
MQTT_USER = ""
MQTT_PASSWORD =""
MQTT_CLIENT_ID =""
MQTT_TOPIC ="utng/aml/led"
MQTT_PORT = 1883

def wifi_connect():
    print("Conectando", end="")
    sta_if = network.WLAN(network.STA_IF)
    sta_if.active(True)
    sta_if.connect("UTNG_Alumnos", "")
    while not sta_if.isconnected():
        print(".",end="")
        sleep(0.3)
    print("WiFi Conectado")

def llegada_mensaje(topico, msg):
    print(msg)
    if msg == b'1':
        led.value(1)
        led2.value(1)
    if msg == b'0':
        led.value(0)
        led2.value(0)
    if msg == b'2':
        servo.duty(0)
        sleep(0.5)
        servo.duty(190)
        sleep(0.5)
        servo.duty(75)
        sleep(0.5)
    if msg == b'5':
        buzzer.duty(0)
    if msg == b'4':
        reproducir_cancion_personalizada()



def subscribir():
    client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, 
        port=MQTT_PORT, 
        user=MQTT_USER, 
        password=MQTT_PASSWORD, 
        keepalive=0)
    client.set_callback(llegada_mensaje)
    client.connect()
    client.subscribe(MQTT_TOPIC)
    print("Conectado en %s, al topico %s"%(MQTT_BROKER, MQTT_TOPIC))
    return client
led = Pin(2, Pin.OUT)
led2 = Pin(15,Pin.OUT)
led.value(0)
led2.value(0)



wifi_connect()
client = subscribir()

while True:
    client.wait_msg()
    foco1.value(1)
    foco2.value(1)
    foco3.value(1)
    foco4.value(1)
    foco5.value(1)
    foco6.value(1)
    




