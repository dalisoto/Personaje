from machine import Pin, PWM
from time import sleep
from hcsr04 import HCSR04

# Configuración de pines para el motor a pasos
IN1 = Pin(26, Pin.OUT)
IN2 = Pin(25, Pin.OUT)
IN3 = Pin(33, Pin.OUT)
IN4 = Pin(32, Pin.OUT)
led = Pin(16, Pin.OUT)
led2 = Pin(17, Pin.OUT)
led3 = Pin(15, Pin.OUT)
serie = Pin(2, Pin.OUT)
pins_motor = [IN1, IN2, IN3, IN4]
sequence_motor = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]

# Configuración de pines para el sensor ultrasónico
sensor = HCSR04(trigger_pin=5,echo_pin=18, echo_timeout_us=20000)

# Configuración del buzzer
buzzer = PWM(Pin(4), freq=440, duty=512)

# Función para girar el motor a pasos
def girar_motor_90_pasos():
    for _ in range(180):
        for step in reversed(sequence_motor):
            for i in range(len(pins_motor)):
                pins_motor[i].value(step[i])
                sleep(0.001)

# Función para revertir el giro del motor a pasos
def revertir_motor_90_pasos():
    for _ in range(180):
        for step in sequence_motor:
            for i in range(len(pins_motor)):
                pins_motor[i].value(step[i])
                sleep(0.001)

# Función para emitir un sonido en el buzzer
def sonido(frecuencia, duracion):
    buzzer.freq(frecuencia)
    buzzer.duty(512)
    sleep(duracion)
    buzzer.duty(0)  # Detener el sonido apagando el buzzer

# Bucle principal
while True:
    distancia = sensor.distance_cm()
    print("Distancia: ", distancia, " cm")
    led.value(1)
    led2.value(1)
    led3.value(1)
    serie.value(1)
    if distancia <= 50:
        serie.value(1)
        girar_motor_90_pasos()

        # Mover el servo mientras el motor se mueve
        for _ in range(180):
            sleep(0.01)
        for _ in range(180):
            sleep(0.01)

        led.value(1)
        led2.value(0)
        led3.value(1)
        revertir_motor_90_pasos()
        sonido(659, 0.5)  # Mi
        sonido(698, 0.5)  # Fa
        sonido(783, 0.5)  # Sol
        sonido(698, 0.5)  # Fa
        led.value(0)
        led2.value(1)
        led3.value(0)
        girar_motor_90_pasos()
        sonido(783, 0.5)  # Sol
        sonido(880, 0.5)  # La
        sonido(783, 0.5)  # Sol

        sonido(698, 0.5)  # Fa
        led.value(1)
        led2.value(1)
        led3.value(1)
        revertir_motor_90_pasos()
        sonido(659, 0.5)  # Mi
        sonido(523, 0.5)  # Do
        sonido(587, 0.5)  # Re
        sonido(659, 0.5)  # Mi
        sonido(698, 0.5)  # Fa
        girar_motor_90_pasos()
        led.value(0)
        led2.value(1)
        led3.value(1)
        sonido(659, 0.5)  # Mi

        sonido(698, 0.5)  # Fa
        sonido(783, 0.5)  # Sol
        sonido(880, 0.5)  # La
        revertir_motor_90_pasos()
        led.value(1)
        led2.value(1)
        led3.value(0)
        sonido(783, 0.5)  # Sol
        sonido(880, 0.5)  # La
        sonido(987, 0.5)  # Si
        sonido(880, 0.5)  # La

        sonido(783, 0.5)  # Sol
        sonido(698, 0.5)  # Fa
        sonido(659, 0.5)  # Mi
        girar_motor_90_pasos()
        led.value(1)
        led2.value(1)
        led3.value(1)
        sleep(0.5)
        led.value(1)
        led2.value(0)
        led3.value(0)
        sleep(0.5)
        led.value(0)
        led2.value(0)
        led3.value(0)
        buzzer.duty(0)
        revertir_motor_90_pasos()

